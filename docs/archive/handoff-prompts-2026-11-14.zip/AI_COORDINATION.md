# Papan Koordinasi AI

Status: TODO | DOING | REVIEW | DONE | BLOCKED

| ID | Tugas | Pemilik | Status | Branch | Catatan |
|----|-------|---------|--------|--------|---------|
| C1 | Modul Komunikasi (pesan/pemberitahuan guru-wali): migration + RLS + API | Codex | TODO | | |
| C2 | Modul Administrasi Dokumen (metadata, kategori, akses per peran) | Codex | TODO | | |
| C3 | Telaah celah PRD vs fitur terpasang, urutkan prioritas | Codex | TODO | | |
| C4 | Perkecil chunk PDF (dynamic import / code splitting) | Codex | TODO | | |
| U1 | UI modul Komunikasi (setelah C1 REVIEW) | Cursor | TODO | | |
| U2 | UI modul Administrasi Dokumen (setelah C2 REVIEW) | Cursor | TODO | | |
| U3 | Audit responsif & aksesibilitas semua halaman | Cursor | TODO | | |
| U4 | Konsistensi state kosong/memuat/galat | Cursor | TODO | | |
| T1 | Perbaiki 2 tes browser (selector alert ambigu), jalankan ulang penuh | Copilot | TODO | | |
| T2 | Tes unit untuk util/validator yang belum tercakup | Copilot | TODO | | |
| T3 | Tes browser Komunikasi & Dokumen (setelah UI REVIEW) | Copilot | TODO | | |
| Q1 | Review keamanan RLS/grant semua migration (laporan saja) | Qoder | TODO | | |
| Q2 | Rapikan README (hapus info usang/duplikat) | Qoder | TODO | | |
| Q3 | Panduan UAT per peran | Qoder | TODO | | |
| Q4 | Review branch AI lain sebelum merge | Qoder | TODO | | |

## Permintaan Lintas AI
(format: dari -> ke, kebutuhan, tanggal)

## Catatan lanjutan (jika kuota habis)
(format: AI, tugas, titik berhenti, langkah berikutnya)

## Urutan merge
Codex (backend) -> Cursor (UI) -> Copilot (tes) -> Qoder (docs). Hanya Codex yang merge ke main.
